function show(){
    document.getElementById('menuUp').classList.remove('inactive');
    document.getElementById('menuUp').classList.add('active');
    console.log('jkbZVJ');
}

window.onload(e => {
    console.log('test');
})